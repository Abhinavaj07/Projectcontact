<?php

namespace App\Http\Controllers;

use App\Models\interviewcontact;

use App\Models\User;
use App\Models\useregister;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Yajra\DataTables\Facades\DataTables;
use Illuminate\Support\Facades\Auth;
use Session;
use Hash;
class InterviewcontactController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        //
        

        $data = interviewcontact::latest()->get();
        
        if ($request->ajax()) {
                        return Datatables::of($data)
                ->addIndexColumn()
                ->addColumn('contactpics',function($data)
                {
                    //return $data->profilepic;
                    $url= asset('storage/'.$data->contactpic);
            //return $url;
            if(empty($data->contactpic))
            {
                return '';
            }
            else
                    return "<img src='".$url."' width='100px'>";
                })
                ->addColumn('action', function($row){
                    $btn = '<a href="javascript:void(0)" class="edit btn btn-primary">Edit</a> <a href=# class="delete btn btn-danger">Delete</a>';
                    return $btn;
                })
                ->rawColumns(['contactpics','action'])
                ->make(true);
        }
    
        return view('contactlist');

    }
    public function mycontacts(Request $request)
    {
        //
        

        $data = interviewcontact::latest()->where("username","=",$request->session()->get("username"))->get();
        
        if ($request->ajax()) {
                        return Datatables::of($data)
                ->addIndexColumn()
                ->addColumn('contactpics',function($data)
                {
                    //return $data->profilepic;
                    $url= asset('storage/'.$data->contactpic);
            //return $url;
            if(empty($data->contactpic))
            {
                return '';
            }
            else
                    return "<img src='".$url."' width='100px'>";
                })
                ->addColumn('action', function($row){
                    $btn = '<a href="javascript:void(0)" class="edit btn btn-primary">Edit</a> <a href=# class="delete btn btn-danger">Delete</a>';
                    return $btn;
                })
                ->rawColumns(['contactpics','action'])
                ->make(true);
        }
    
        return view('mycontacts');

    }


    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
        return view("contact");
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
/*         request()->validate([
            'category' => 'required',
            'subcategory' => 'required',
                    ]);
        $sub =new subcategory();
        $sub->categoryid=$request->category;
        $sub->subcatname=$request->subcategory;
        $sub->save();
        return redirect('subcategory'); */
        $contact=new interviewcontact();
        $contact ->Name=$request->contactname;
        $contact ->Address=$request->address;
        $contact ->Email=$request->email;
        $contact ->Phonenumberone=$request->phonenumberone;
        $contact ->Phonenumbertwo=$request->phonenumbertwo;
        $contact->username=$request->session()->get("username");
        if($request->hasfile('upload'))
        {
                    
       //dd(Storage::disk('public')->put('contacts',$request->upload));
       $image= Storage::disk('public')->put('contacts',$request->upload);
       $contact->contactpic =$image;
          }  
        
        $contact->save();
        return view('contact');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\interviewcontact  $interviewcontact
     * @return \Illuminate\Http\Response
     */
    public function show(interviewcontact $interviewcontact)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\interviewcontact  $interviewcontact
     * @return \Illuminate\Http\Response
     */
    public function edit(interviewcontact $interviewcontact)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\interviewcontact  $interviewcontact
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, interviewcontact $interviewcontact)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\interviewcontact  $interviewcontact
     * @return \Illuminate\Http\Response
     */
    public function destroy(interviewcontact $interviewcontact)
    {
        //
    }
}
