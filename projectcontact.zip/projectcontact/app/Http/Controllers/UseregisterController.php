<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\useregister;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Yajra\DataTables\Facades\DataTables;
use Illuminate\Support\Facades\Auth;
use Session;
use Hash;

class UseregisterController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
public function validatelogin(Request $request)
{
    $data = User::where("users.username","=",$request->username)
    ->where("users.password","=",$request->password)->get("username","type");
   
    
if($data[0]["username"]!=null&& $data[0]["username"]!="admin")
{$request->session()->put('username',$data[0]["username"]);
  
    return redirect ("userdashboard");
   
}else if($data[0]["username"]!=null&& $data[0]["username"]=="admin")
{
   
    $request->session()->put('username',$data[0]["username"]);
  
return redirect("admindashboard");
}
}

public function userdashboard()
{return view("userdashboard");
}

public function admindashboard()
{return view("admindashboard");
}
public function myprofile(Request $request)
{
    $data = User::latest()->where("username","=",$request->session()->get("username"))
    ->get();
    return view("myprofile")->with('data',$data);//->with('path',$data[0]->profilepic);
    //dd($data);
}
 public function index(Request $request)
    {
        $data = User::latest()->get();
        
        if ($request->ajax()) {
            
            return Datatables::of($data)
                ->addIndexColumn()
                ->addColumn('profilepics',function($data)
                {
                    //return $data->profilepic;
                    $url= asset('storage/'.$data->profilepic);
            //return $url;
            if(empty($data->profilepic))
            {
                return '';
            }
            else
                    return "<img src='".$url."' width='100px'>";
                })
                ->addColumn('action', function($row){
                    $btn = '<a href="javascript:void(0)" class="edit btn btn-primary">Edit</a> <a href=# class="delete btn btn-danger">Delete</a>';
                    return $btn;
                })
                ->rawColumns(['profilepics','action'])
                ->make(true);
        }
    
        return view('registerlist');


    }
    public function signin(Request $request)
    {
        $request->validate([
            '' => 'required',
            'password' => 'required',
        ]);
        $credentials = $request->$request->only( 'password');
   
        if (Auth::attempt($credentials,true)) {
            dd("auth");
            return redirect()->intended('dashboard')
                        ->withSuccess('Logged-in');
        }
        dd("error");
        return redirect("login")->withSuccess('Credentials are wrong.');
    }
    
    public function dashboardView()
    {
        if(Auth::check()){
            return view('dashboard');
        }
        return redirect("login")->withSuccess('Access is not permitted');
    }

    public function logout(Request $request) {
        //Session::flush();
       // Auth::logout();
       $request->session()->forget('username');  
///return $request->session()->all();  

        return view('login');
    }

    
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
        return view("register");
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {try{
            
        $register=new user();
        $register->Name=$request->name;
        $register->Email=$request->email;
        $register->Phonenumber=$request->phonenumber;
        $register->Username=$request->username;
        $register->Password= ($request->password);
        
        if($request->hasfile('upload'))
        {
                    
        $profileimage = $request->file('upload');
        $extension = $profileimage->getClientOriginalExtension();
       
       $image= Storage::disk('public')->put('profile',$request->upload);
       $register->profilepic =$image;
          }  
        $register->save();
        $request->session()->put('username',$request->username);
 
    }
    catch (\Throwable $th) {
        //dd($th->getMessage()->withInput());
        $msg="please check your data. username already exists";
        return back()->withError($msg)->withInput();
    }
   

        return view('myprofile');

    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\useregister  $useregister
     * @return \Illuminate\Http\Response
     */
    public function show(useregister $useregister)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\useregister  $useregister
     * @return \Illuminate\Http\Response
     */
    public function edit(useregister $useregister)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\useregister  $useregister
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, useregister $useregister)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\useregister  $useregister
     * @return \Illuminate\Http\Response
     */
    public function destroy(useregister $useregister)
    {
        //
    }
    
}
