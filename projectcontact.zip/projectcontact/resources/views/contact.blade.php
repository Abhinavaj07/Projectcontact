@extends('usermaster')
@section('title','ADD CONTACT')
@section('content')
<form method="post" action="{{route('contact.store')}}" enctype="multipart/form-data">@csrf 
Name<input type="name" name="contactname" required><br>
Addres<textarea rows=4 cols=20 name="address" required></textarea><br>
Email<input type="email" name="email" required><br>
Phone One<input type="text" name="phonenumberone" required><br>
Phone Two<input type="text" name="phonenumbertwo" required><br>
Upload  Photo<input type="file" name="upload"><br>

<input type="submit" value="save" >
</form>
@endsection