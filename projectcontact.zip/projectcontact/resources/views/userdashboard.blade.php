@extends('usermaster')
@section('title','WELCOME TO MACHINE TEST')