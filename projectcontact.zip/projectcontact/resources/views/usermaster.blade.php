<h4><a href="{{ route('myprofile') }}">My profile</a>
<a href="{{ route('mycontacts') }}">My Contacts</a>

<a href="{{ route('contact.create') }}">Add Contacts</a>

<a href="/">logout</a></h4>
<br><h2>
@yield('title')
</h2>
@yield('content')
