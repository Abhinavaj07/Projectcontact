
<?php $__env->startSection('title','ADD CONTACT'); ?>
<?php $__env->startSection('content'); ?>
<form method="post" action="<?php echo e(route('contact.store')); ?>" enctype="multipart/form-data"><?php echo csrf_field(); ?> 
Name<input type="name" name="contactname" required><br>
Addres<textarea rows=4 cols=20 name="address" required></textarea><br>
Email<input type="email" name="email" required><br>
Phone One<input type="text" name="phonenumberone" required><br>
Phone Two<input type="text" name="phonenumbertwo" required><br>
Upload  Photo<input type="file" name="upload"><br>

<input type="submit" value="save" >
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('usermaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Mywork\interviewwork\resources\views/contact.blade.php ENDPATH**/ ?>