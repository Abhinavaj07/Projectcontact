<h4><a href="<?php echo e(route('myprofile')); ?>">My profile</a>
<a href="<?php echo e(route('mycontacts')); ?>">My Contacts</a>

<a href="<?php echo e(route('contact.create')); ?>">Add Contacts</a>

<a href="/">logout</a></h4>
<br><h2>
<?php echo $__env->yieldContent('title'); ?>
</h2>
<?php echo $__env->yieldContent('content'); ?>
<?php /**PATH C:\Mywork\interviewwork\resources\views/usermaster.blade.php ENDPATH**/ ?>