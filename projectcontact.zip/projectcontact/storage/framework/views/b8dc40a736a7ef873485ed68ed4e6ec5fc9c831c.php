<a href="<?php echo e(route('register.index')); ?>">users list</a>
<br>
<a href="<?php echo e(route('contact.index')); ?>">contactlist</a>
<br>
<!-- <a href="<?php echo e(route('logout')); ?>">logout</a> --><?php /**PATH C:\Mywork\interviewwork\resources\views/admindashboard.blade.php ENDPATH**/ ?>